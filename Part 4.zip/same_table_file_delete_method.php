public function removeFeaturedImage($parent_id)
	{
		$crud = $this->crud;
		$current_values = $crud->current_values($parent_id);
		if (!$current_values)
			return redirect()->to($crud->getBase() . '/' . $crud->getTable());

		$fileColumnName = 'p_image';
		$field = $crud->getFields($fileColumnName);
		
		$table = $crud->getTable();
		$data = [$fileColumnName => ''];
		$where = [$crud->get_primary_key_field_name() => $parent_id];
		$affected = $crud->updateItem($table, $where, $data);
		
		if (!$affected)
		$crud->flash('warning', 'File could not be deleted');
		else {

			if ($field['delete_file'] ?? false && $field['delete_file'] === TRUE)
				unlink($field['path'] . '/' .  $crud->current_values->{$fileColumnName});

			$crud->flash('success', 'File was deleted');
		}

		$url = $crud->getBase() . '/' . $crud->getTable() . '/edit/' . $parent_id;
		return redirect()->to($url);
	}